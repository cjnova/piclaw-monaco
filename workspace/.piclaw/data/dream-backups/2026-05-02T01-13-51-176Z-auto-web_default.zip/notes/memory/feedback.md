# Feedback memory

## Corrections and steering cues

### 2026-05-01: Follow routing rules — stop doing inline investigation
- **Violation:** Traced model resolution across 8+ files inline (tools.ts, select.ts, tiers.ts, categories.ts, metadata.json, launch.sh, last-capture.txt) instead of spawning a fleet agent. Ballooned context to 103k tokens.
- **Rule:** After ONE read to orient, if the task needs more files → fleet it immediately. No exceptions.
- **Auto-fleet triggers I ignored:** unknown-failure debugging, multi-file investigation, unfamiliar code exploration.
- **Correct pattern:** Inline triage ("this needs investigation") → fleet_spawn → read summary → report to user.

### 2026-05-01: Target correct GitHub repo
- Default repo is `cjnova/piclaw-monaco` (origin), NOT `rcarmo/piclaw` (upstream). Always check `git remote -v` or use `--repo` flag explicitly.
