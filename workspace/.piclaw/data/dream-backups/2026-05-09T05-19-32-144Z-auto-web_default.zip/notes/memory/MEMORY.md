# MEMORY.md

Dream-maintained memory index generated from the message database plus human-readable daily notes.

Generated: 2026-05-08T12:25:31.709Z

## Status

- Window: last 7 days
- Complete days: 5
- Partial days: 0
- Unsummarised days: 0
- Latest complete day: 2026-05-07

## Memory types

- [User memory](user.md) — role and preferences the agent should keep stable
- [Feedback memory](feedback.md) — corrections, steering cues, and remembered constraints
- [Project memory](project.md) — ongoing work, recent outcomes, and pending follow-up
- [Reference memory](reference.md) — note index and durable external pointers

## Recent daily memories

- [2026-05-07](../daily/2026-05-07.md)
  - Brief afternoon widget testing session (15:04–15:24 UTC, 24 messages). User tested dashboard widget functiona…
- [2026-05-05](../daily/2026-05-05.md)
  - Full-day QA and testing session (08:20–15:10 UTC, 68 messages). Browser notification testing (permission chec…
- [2026-05-04](../daily/2026-05-04.md)
  - Full-day QA and development session (08:08–16:19 UTC). Morning phase: connectivity testing followed by 7+ rep…
- [2026-05-03](../daily/2026-05-03.md)
  - Afternoon UI testing session (15:35–16:34 UTC). User tested web frontend rendering: multiple greeting message…
- [2026-05-02](../daily/2026-05-02.md)
  - Brief evening session with 6 messages (3 user, 3 assistant) in a ~2-minute window (20:45–20:47 UTC). Single s…

## Sources

- [current-state.md](current-state.md)
- [recent-context.md](recent-context.md)
- Daily notes directory: /workspace/piclaw-monaco/workspace/notes/daily
- Sparse day-memory directory (model-owned, optional): /workspace/piclaw-monaco/workspace/notes/memory/days
