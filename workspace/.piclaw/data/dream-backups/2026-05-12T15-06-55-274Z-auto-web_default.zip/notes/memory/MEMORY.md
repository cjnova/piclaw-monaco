# MEMORY.md

Dream-maintained memory index generated from the message database plus human-readable daily notes.

Generated: 2026-05-12T15:06:01.926Z

## Status

- Window: last 7 days
- Complete days: 3
- Partial days: 0
- Unsummarised days: 0
- Latest complete day: 2026-05-08

## Memory types

- [User memory](user.md) — role and preferences the agent should keep stable
- [Feedback memory](feedback.md) — corrections, steering cues, and remembered constraints
- [Project memory](project.md) — ongoing work, recent outcomes, and pending follow-up
- [Reference memory](reference.md) — note index and durable external pointers

## Recent daily memories

- [2026-05-08](../daily/2026-05-08.md)
  - Light housekeeping day (13:40–21:38 UTC, 60 messages across 2 sessions). Two `/compact` runs: first reduced c…
- [2026-05-07](../daily/2026-05-07.md)
  - Brief afternoon widget testing session (15:04–15:24 UTC, 24 messages). User tested dashboard widget functiona…
- [2026-05-05](../daily/2026-05-05.md)
  - Full-day QA and testing session (08:20–15:10 UTC, 68 messages). Browser notification testing (permission chec…

## Sources

- [current-state.md](current-state.md)
- [recent-context.md](recent-context.md)
- Daily notes directory: /workspace/piclaw-monaco/workspace/notes/daily
- Sparse day-memory directory (model-owned, optional): /workspace/piclaw-monaco/workspace/notes/memory/days
